//
//  KGEcharts.h
//  KGEcharts
//
//  Created by 北师智慧 on 2019/8/21.
//  Copyright © 2019 KG. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KGEcharts.
FOUNDATION_EXPORT double KGEchartsVersionNumber;

//! Project version string for KGEcharts.
FOUNDATION_EXPORT const unsigned char KGEchartsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KGEcharts/PublicHeader.h>

#import "KGLineView.h"
#import "KGPieView.h"
