#import <UIKit/UIKit.h>

@class KGLineView;

@protocol KGLineViewDelegate <NSObject>

/**
 设置y轴标题

 @return y轴标题
 */
- (NSString *)theYAxisTitle;
/**
 设置x轴标题
 
 @return x轴标题
 */
- (NSString *)theXAxisTitle;

@end

@protocol KGLineViewDataSource <NSObject>

@required
/**
 设置y轴分区数

 @return y轴分区数
 */
- (NSInteger)numberOfSliceInYAxis;
/**
 设置x轴分区数
 
 @return x轴分区数
 */
- (NSInteger)numberOfSliceInXAxis;
/**
 设置y轴分区标题

 @param lineView 折线view
 @param index 分区index
 @return y轴分区标题
 */
- (NSString *)lineView:(KGLineView *)lineView titleForYAxisAtIndex:(NSInteger)index;
/**
 设置x轴分区标题
 
 @param lineView 折线view
 @param index 分区index
 @return x轴分区标题
 */
- (NSString *)lineView:(KGLineView *)lineView titleForXAxisAtIndex:(NSInteger)index;
/**
 设置x轴折线峰值

 @param lineView 折线view
 @param index 分区index
 @return x轴折线峰值
 */
- (float)lineView:(KGLineView *)lineView valueForXAxisAtIndex:(NSInteger)index;

@optional
/**
 设置是否在峰值处显示具体数据

 @param lineView 折线view
 @param index 分区index
 @return 是否在峰值处显示具体数据
 */
- (BOOL)lineView:(KGLineView *)lineView isShowTitleForLineAtIndex:(NSInteger)index;
/**
 设置在峰值处显示的内容

 @param lineView 折线view
 @param index 分区index
 @return 在峰值处显示的内容
 */
- (NSString *)lineView:(KGLineView *)lineView showTitleForLineAtIndex:(NSInteger)index;

@end


@interface KGLineView : UIView

@property (nonatomic,weak) id<KGLineViewDelegate> delegate;
@property (nonatomic,weak) id<KGLineViewDataSource> dataSource;

@end

