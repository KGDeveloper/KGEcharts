#import <UIKit/UIKit.h>


@class KGPieView;
@protocol KGPieViewDelegate <NSObject>

/**
 中心圆的半径

 @return 中心圆半径
 */
- (CGFloat)centerCircleRadius;

@end

@protocol KGPieViewDataSource <NSObject>

@required
/**
 设置切片个数

 @param pieChartView 切片view
 @return 切片个数
 */
- (NSInteger)numberOfSlicesInPieChartView:(KGPieView *)pieChartView;

/**
 获取切片区域大小

 @param pieChartView 切片view
 @param index 区域下标
 @return 切片区域大小
 */
- (CGFloat)pieChartView:(KGPieView *)pieChartView valueForSliceAtIndex:(NSInteger)index;

/**
 获取切片颜色

 @param pieChartView 切片view
 @param index 切片区域下标
 @return 切片颜色
 */
- (UIColor *)pieChartView:(KGPieView *)pieChartView colorForSliceAtIndex:(NSInteger)index;

@optional
/**
 设置切片区域显示文本

 @param pieChartView 切片view
 @param index 切片区域下标
 @return 切片区域显示文本
 */
- (NSString *)pieChartView:(KGPieView *)pieChartView titleForSliceAtIndex:(NSInteger)index;

@end

@interface KGPieView : UIView

/**
 代理控制圆大小
 */
@property (nonatomic,weak) id <KGPieViewDelegate> delegate;

/**
 代理控制扇形图属性
 */
@property (nonatomic,weak) id <KGPieViewDataSource> dataSource;

/**
 属性扇形图
 */
- (void)reloadData;

@end

